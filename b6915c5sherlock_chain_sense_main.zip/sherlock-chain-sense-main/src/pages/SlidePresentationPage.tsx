
import SlidePresentation from "@/components/SlidePresentation";

const SlidePresentationPage = () => {
  return <SlidePresentation />;
};

export default SlidePresentationPage;


import SubmissionChecklist from "@/components/SubmissionChecklist";

const SubmissionChecklistPage = () => {
  return <SubmissionChecklist />;
};

export default SubmissionChecklistPage;


import DemoVideoScript from "@/components/DemoVideoScript";

const DemoVideoScriptPage = () => {
  return <DemoVideoScript />;
};

export default DemoVideoScriptPage;

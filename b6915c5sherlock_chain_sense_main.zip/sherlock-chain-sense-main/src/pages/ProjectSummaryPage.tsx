
import ProjectSummary from "@/components/ProjectSummary";

const ProjectSummaryPage = () => {
  return <ProjectSummary />;
};

export default ProjectSummaryPage;

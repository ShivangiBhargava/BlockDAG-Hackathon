
import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play, Video, Clock, Target, Rocket } from "lucide-react";

const DemoVideoScript = () => {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <Video className="w-8 h-8 text-purple-600" />
          <h1 className="text-3xl font-bold">Demo Video Script</h1>
          <Badge variant="outline" className="bg-red-50 text-red-700">2-5 Minutes</Badge>
        </div>

        <div className="space-y-8">
          {/* Scene 1 */}
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-purple-600" />
              <h3 className="text-xl font-semibold">Scene 1: Hook & Problem (30 seconds)</h3>
            </div>
            <div className="space-y-3">
              <div className="bg-white p-4 rounded border-l-4 border-purple-500">
                <h4 className="font-semibold mb-2">🎬 Visual: Show Sherlock AI homepage</h4>
                <p className="text-sm italic">"Meet Sherlock AI - DeFi's first AI-powered transaction explainer. In 2022 alone, $3.8 billion was lost to DeFi hacks. Users struggle to understand if transactions are safe. Today, I'll show you how Sherlock AI solves this with BlockDAG integration."</p>
              </div>
              <div className="text-xs text-gray-600">
                <strong>Key Visual:</strong> Homepage → Risk score examples → Problem statistics
              </div>
            </div>
          </div>

          {/* Scene 2 */}
          <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-blue-600" />
              <h3 className="text-xl font-semibold">Scene 2: Live Demo - Core Features (2 minutes)</h3>
            </div>
            <div className="space-y-3">
              <div className="bg-white p-4 rounded border-l-4 border-blue-500">
                <h4 className="font-semibold mb-2">🎬 Visual: Live transaction analysis</h4>
                <p className="text-sm italic">"Let me analyze a real BlockDAG transaction. I'll paste this transaction hash... Watch as our AI instantly provides a risk score of 8/10 - HIGH RISK. It detected an unverified contract requesting unlimited token approval - a classic token drainer pattern."</p>
              </div>
              <div className="grid md:grid-cols-2 gap-4 mt-4">
                <div className="bg-red-50 p-3 rounded">
                  <h5 className="font-medium text-red-800">Sample High-Risk TX:</h5>
                  <code className="text-xs">0x123...abc (Unverified contract)</code>
                </div>
                <div className="bg-green-50 p-3 rounded">
                  <h5 className="font-medium text-green-800">Sample Safe TX:</h5>
                  <code className="text-xs">0x456...def (Verified DEX)</code>
                </div>
              </div>
            </div>
          </div>

          {/* Scene 3 */}
          <div className="bg-gradient-to-r from-green-50 to-orange-50 p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Rocket className="w-5 h-5 text-green-600" />
              <h3 className="text-xl font-semibold">Scene 3: BlockDAG Integration (1 minute)</h3>
            </div>
            <div className="space-y-3">
              <div className="bg-white p-4 rounded border-l-4 border-green-500">
                <h4 className="font-semibold mb-2">🎬 Visual: Network status + Smart contract</h4>
                <p className="text-sm italic">"Our RiskOracle smart contract is live on BlockDAG testnet. You can see real network stats - 2,000+ TPS, 1.5s block time. The contract stores risk assessments on-chain for transparency. Here's our deployed contract address on BlockDAG explorer."</p>
              </div>
              <div className="bg-purple-50 p-3 rounded">
                <h5 className="font-medium">Demo Elements:</h5>
                <ul className="text-sm list-disc list-inside space-y-1">
                  <li>BlockDAG network status dashboard</li>
                  <li>Live contract on testnet explorer</li>
                  <li>Risk oracle functionality</li>
                  <li>Real-time transaction processing</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Scene 4 */}
          <div className="bg-gradient-to-r from-orange-50 to-red-50 p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Play className="w-5 h-5 text-orange-600" />
              <h3 className="text-xl font-semibold">Scene 4: Wrap-up & CTA (30 seconds)</h3>
            </div>
            <div className="space-y-3">
              <div className="bg-white p-4 rounded border-l-4 border-orange-500">
                <h4 className="font-semibold mb-2">🎬 Visual: Team info + GitHub</h4>
                <p className="text-sm italic">"Sherlock AI makes DeFi safer with AI-powered transaction analysis on BlockDAG. Try it yourself with any transaction hash. Built by Team Real and Ready for BlockDAG Hackathon 2025. Check out our open-source code on GitHub."</p>
              </div>
              <div className="bg-gray-50 p-3 rounded">
                <h5 className="font-medium">Call to Action:</h5>
                <ul className="text-sm list-disc list-inside">
                  <li>Try the live demo at [URL]</li>
                  <li>View source on GitHub</li>
                  <li>BlockDAG contract: [Address]</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Production Notes */}
        <div className="mt-8 bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-4">📽️ Production Notes</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-2">Recording Setup:</h4>
              <ul className="text-sm space-y-1">
                <li>• Screen recording at 1080p</li>
                <li>• Clear audio narration</li>
                <li>• 2-5 minute max duration</li>
                <li>• Upload to YouTube</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Key Talking Points:</h4>
              <ul className="text-sm space-y-1">
                <li>• Live on BlockDAG testnet</li>
                <li>• AI risk assessment (1-10 scale)</li>
                <li>• Real transaction analysis</li>
                <li>• Open source & hackathon entry</li>
              </ul>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default DemoVideoScript;
